/******************************************************************************
 * @file    main.c
 * @author  Javier
 * @date    2026
 *
 * @brief
 * Main entry point of the ESP32-S3 Flight Display firmware.
 *
 * This module is responsible only for the initialization and startup of the
 * different software modules that compose the application. It does not perform
 * any data processing, communication or sensor acquisition by itself.
 *
 * ---------------------------------------------------------------------------
 * SOFTWARE ARCHITECTURE
 * ---------------------------------------------------------------------------
 *
 *                  +----------------+
 *                  |    main.c      |
 *                  +----------------+
 *                           |
 *          -----------------------------------------
 *          |                  |                    |
 *          v                  v                    v
 *    wifi_ap.c          webserver.c         websocket.c
 *          |                  |                    |
 *          |                  |                    |
 *          |           HTTP Server                 |
 *          |           "/" -> index.html           |
 *          |           "/ws" -> WebSocket          |
 *          |                  |                    |
 *          +------------------+--------------------+
 *                             |
 *                             v
 *                    Mobile / PC Browser
 *
 *
 * Future versions will incorporate additional modules:
 *
 *          imu.c
 *          barometer.c
 *          telemetry.c
 *          sensor_fusion.c
 *
 * which will provide real flight information to the WebSocket server.
 *
 *
 * ---------------------------------------------------------------------------
 * CURRENT DATA FLOW
 * ---------------------------------------------------------------------------
 *
 *                  Dummy telemetry task (25 Hz)
 *                             |
 *                             v
 *                   JSON telemetry generation
 *                             |
 *                             v
 *                   WebSocket broadcast (/ws)
 *                             |
 *                             v
 *                      Browser JavaScript
 *                             |
 *                             v
 *                       HTML visualisation
 *
 *
 * ---------------------------------------------------------------------------
 * INITIALIZATION SEQUENCE
 * ---------------------------------------------------------------------------
 *
 * app_main()
 *
 *      1. Initialize NVS
 *      2. Start Wi-Fi Access Point
 *      3. Start HTTP Server
 *      4. Register WebSocket endpoint
 *      5. Start dummy telemetry task (25 Hz)
 *      6. System ready
 *
 *
 * ---------------------------------------------------------------------------
 * MODULE RESPONSIBILITIES
 * ---------------------------------------------------------------------------
 *
 * main.c
 *      Overall application startup.
 *
 * wifi_ap.c
 *      Configures the ESP32-S3 as a Wi-Fi Access Point.
 *
 * webserver.c
 *      Starts the HTTP server and serves the embedded HTML page.
 *
 * websocket.c
 *      Handles WebSocket clients and periodically transmits telemetry.
 *
 *
 * ---------------------------------------------------------------------------
 * FUTURE ARCHITECTURE
 * ---------------------------------------------------------------------------
 *
 *               IMU ---------------------+
 *                                        |
 *               Barometer ---------------+
 *                                        |
 *               GPS ---------------------+
 *                                        |
 *                                        v
 *                              telemetry.c
 *                                        |
 *                                        v
 *                              websocket.c
 *                                        |
 *                                        v
 *                                HTML Interface
 *
 * This architecture keeps hardware acquisition completely independent from
 * the communication layer, allowing each module to be developed and tested
 * independently.
 *
 ******************************************************************************/

#include "esp_log.h"
#include "nvs_flash.h"
#include "wifi_ap.h"
#include "webserver.h"
#include "websocket.h"

static const char *TAG = "MAIN";

void app_main(void)
{
    esp_err_t err = nvs_flash_init();
    if ((err == ESP_ERR_NVS_NO_FREE_PAGES) || (err == ESP_ERR_NVS_NEW_VERSION_FOUND))
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    else
    {
        ESP_ERROR_CHECK(err);
    }

    ESP_ERROR_CHECK(wifi_ap_start()); // arranca el Access point

    httpd_handle_t server = webserver_start(); // arranca el servidor web http
    if (server == NULL)
    {
        ESP_LOGE(TAG, "No se ha podido iniciar el servidor web");
        return;
    }

    ESP_ERROR_CHECK(websocket_start_dummy_stream(server)); // Register WebSocket endpoint

    ESP_LOGI(TAG, "Sistema iniciado correctamente");
}
