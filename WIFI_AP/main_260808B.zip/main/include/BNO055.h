#ifndef BNO055_H
#define BNO055_H

#include <stdbool.h>
#include <stdint.h>
#include "esp_err.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    float x;
    float y;
    float z;
} bno055_vector3f_t;

typedef struct
{
    float w;
    float x;
    float y;
    float z;
} bno055_quaternionf_t;

typedef struct
{
    /*
     * Aceleración total en los ejes físicos instalados:
     *
     *   +X -> ala izquierda
     *   +Y -> morro
     *   +Z -> arriba
     *
     * Se publica en G para mantener compatibilidad con el EFIS.
     */
    float accel_x_g;
    float accel_y_g;
    float accel_z_g;
    float accel_total_g;

    /* Aceleración total original del BNO055 [m/s²]. */
    bno055_vector3f_t acceleration_ms2;

    /* Aceleración lineal calculada por el motor de fusión [m/s²]. */
    bno055_vector3f_t linear_acceleration_ms2;

    /* Vector de gravedad calculado por el motor de fusión [m/s²]. */
    bno055_vector3f_t gravity_ms2;

    /* Campo magnético [µT]. */
    bno055_vector3f_t magnetic_field_ut;

    /* Velocidades angulares del cuerpo [deg/s]. */
    float gyro_x_dps;
    float gyro_y_dps;
    float gyro_z_dps;

    /*
     * Actitud NDOF:
     *
     *   heading_deg -> rumbo alrededor de Z
     *   roll_deg    -> alabeo alrededor de Y (longitudinal)
     *   pitch_deg   -> cabeceo alrededor de X (transversal)
     */
    float heading_deg;
    float roll_deg;
    float pitch_deg;

    /* Cuaternión de orientación proporcionado por el BNO055. */
    bno055_quaternionf_t quaternion;

    /*
     * Velocidad de cambio de rumbo [deg/s].
     * Se calcula derivando heading_deg, con unwrap y filtro paso bajo.
     * Se utiliza en el coordinador de giro.
     */
    float yaw_rate_dps;

    /*
     * Posición de la bola del coordinador.
     * Se obtiene de la aceleración específica transversal medida en X
     * (+X hacia el ala izquierda) y se filtra.
     */
    float slip_ball_deg;

    /*
     * G-meter compatible con la interfaz actual:
     *   g_current = accel_z_g - 1.0 g
     *   g_max / g_min retienen los extremos desde el último RESET.
     */
    float g_current;
    float g_max;
    float g_min;

    /* Temperatura interna del BNO055 [°C]. */
    int8_t temperature_c;

    /* Estado de calibración, 0..3. */
    uint8_t calibration_system;
    uint8_t calibration_gyro;
    uint8_t calibration_accel;
    uint8_t calibration_mag;

    bool valid;

} bno055_data_t;

/**
 * @brief Inicializa el BNO055 en NDOF y crea su tarea periódica.
 *
 * El bus I2C debe estar previamente inicializado por main.c.
 */
esp_err_t BNO055_start(void);

/**
 * @brief Devuelve una instantánea atómica de los últimos datos válidos.
 */
bno055_data_t BNO055_get_data(void);

/**
 * @brief Resetea a cero las tres agujas/memorias del G-meter.
 */
void BNO055_reset_accel_peaks(void);

#ifdef __cplusplus
}
#endif

#endif /* BNO055_H */
