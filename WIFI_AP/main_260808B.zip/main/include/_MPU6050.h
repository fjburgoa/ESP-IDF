#ifndef _MPU6050_H
#define _MPU6050_H

#include "esp_err.h"

#ifdef __cplusplus
extern "C"
{
#endif

    esp_err_t MPU6050_start(void);

#ifdef __cplusplus
}
#endif

#endif
