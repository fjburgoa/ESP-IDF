#ifndef HYBRID_PITCH_ROLL_H
#define HYBRID_PITCH_ROLL_H
#include <stdbool.h>
typedef struct {
    float pitch_deg, roll_deg, accel_weight;
    float accel_norm_ms2, gravity_norm_ms2, accel_error_ms2;
    float angle_error_deg, accel_mod_weight, accel_angle_weight;
    bool valid;
} hybrid_pitch_roll_data_t;
hybrid_pitch_roll_data_t Hybrid_pitch_roll_update(float ax,float ay,float az,float gx,float gy,float gz);
hybrid_pitch_roll_data_t Hybrid_pitch_roll_update_double(float ax,float ay,float az,float gx,float gy,float gz);
#endif
