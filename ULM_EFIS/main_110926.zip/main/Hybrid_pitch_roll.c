/**
 * @file Hybrid_pitch_roll.c
 * @brief Fusión experimental MPU6050 + GRAVITY del BNO055 para pitch/roll.
 */

#include "Hybrid_pitch_roll.h"

#include <math.h>

#include "config.h"

#define RAD_TO_DEG 57.29577951308232f
#define STANDARD_GRAVITY_MS2 9.80665f
#define MIN_VECTOR_NORM 0.1f

/* -------------------------------------------------------------------------- */

static float clampf_local(float value, float minimum, float maximum)
{
    if (value < minimum)
    {
        return minimum;
    }

    if (value > maximum)
    {
        return maximum;
    }

    return value;
}

/* -------------------------------------------------------------------------- */

static float linear_weight(float value, float low, float high)
{
    if (value <= low)
    {
        return 1.0f;
    }

    if (value >= high)
    {
        return 0.0f;
    }

    return clampf_local((high - value) / (high - low),
                        0.0f,
                        1.0f);
}

/* -------------------------------------------------------------------------- */

static bool gravity_is_valid(float gravity_norm_ms2)
{
    return isfinite(gravity_norm_ms2) &&
           (gravity_norm_ms2 >= ATTITUDE_GRAVITY_VALID_MIN_MS2) &&
           (gravity_norm_ms2 <= ATTITUDE_GRAVITY_VALID_MAX_MS2);
}

/* -------------------------------------------------------------------------- */

static void vector_to_attitude(float x,
                               float y,
                               float z,
                               float *roll_deg,
                               float *pitch_deg)
{
    const float z_squared = z * z;

    /* Convención de ejes histórica del EFIS. */
    *pitch_deg = atan2f(y, sqrtf((x * x) + z_squared)) * RAD_TO_DEG;
    *roll_deg = atan2f(x, sqrtf((y * y) + z_squared)) * RAD_TO_DEG;
}

/* -------------------------------------------------------------------------- */

static hybrid_pitch_roll_data_t hybrid_compute(float accel_x,
                                                float accel_y,
                                                float accel_z,
                                                float gravity_x,
                                                float gravity_y,
                                                float gravity_z,
                                                bool use_angle_criterion)
{
    hybrid_pitch_roll_data_t output = {0};

    const float accel_norm_ms2 = sqrtf((accel_x * accel_x) +
                                       (accel_y * accel_y) +
                                       (accel_z * accel_z));

    const float gravity_norm_ms2 = sqrtf((gravity_x * gravity_x) +
                                         (gravity_y * gravity_y) +
                                         (gravity_z * gravity_z));

    const float accel_error_ms2 = fabsf(accel_norm_ms2 - STANDARD_GRAVITY_MS2);

    output.accel_norm_ms2 = accel_norm_ms2;
    output.gravity_norm_ms2 = gravity_norm_ms2;
    output.accel_error_ms2 = accel_error_ms2;

    if ((!isfinite(accel_norm_ms2)) || (accel_norm_ms2 < MIN_VECTOR_NORM))
    {
        return output;
    }

    float accel_mod_weight = linear_weight(accel_error_ms2,
                                           ATTITUDE_ACCEL_ERROR_LOW_MS2,
                                           ATTITUDE_ACCEL_ERROR_HIGH_MS2);

    float accel_angle_weight = 1.0f;
    float angle_error_deg = 0.0f;

    if (!gravity_is_valid(gravity_norm_ms2))
    {
        /*
         * Si GRAVITY todavía no es válido, no se utiliza para contaminar una
         * medida válida del MPU6050. El algoritmo cae temporalmente a MPU puro.
         */
        accel_mod_weight = 1.0f;
        accel_angle_weight = 1.0f;
    }
    else if (use_angle_criterion)
    {
        float cosine = ((accel_x * gravity_x) +
                        (accel_y * gravity_y) +
                        (accel_z * gravity_z)) /
                       (accel_norm_ms2 * gravity_norm_ms2);

        cosine = clampf_local(cosine, -1.0f, 1.0f);
        angle_error_deg = acosf(cosine) * RAD_TO_DEG;

        accel_angle_weight = linear_weight(angle_error_deg,
                                           ATTITUDE_ANGLE_ERROR_LOW_DEG,
                                           ATTITUDE_ANGLE_ERROR_HIGH_DEG);
    }

    const float accel_weight = use_angle_criterion
                                   ? accel_mod_weight * accel_angle_weight
                                   : accel_mod_weight;

    const float hybrid_x = (accel_weight * accel_x) +
                           ((1.0f - accel_weight) * gravity_x);

    const float hybrid_y = (accel_weight * accel_y) +
                           ((1.0f - accel_weight) * gravity_y);

    const float hybrid_z = (accel_weight * accel_z) +
                           ((1.0f - accel_weight) * gravity_z);

    const float hybrid_norm = sqrtf((hybrid_x * hybrid_x) +
                                    (hybrid_y * hybrid_y) +
                                    (hybrid_z * hybrid_z));

    if ((!isfinite(hybrid_norm)) || (hybrid_norm < MIN_VECTOR_NORM))
    {
        return output;
    }

    vector_to_attitude(hybrid_x,
                       hybrid_y,
                       hybrid_z,
                       &output.roll_deg,
                       &output.pitch_deg);

    output.accel_weight = accel_weight;
    output.angle_error_deg = angle_error_deg;
    output.accel_mod_weight = accel_mod_weight;
    output.accel_angle_weight = accel_angle_weight;
    output.valid = true;

    return output;
}

/* -------------------------------------------------------------------------- */

hybrid_pitch_roll_data_t Hybrid_pitch_roll_update(float accel_x,
                                                  float accel_y,
                                                  float accel_z,
                                                  float gravity_x,
                                                  float gravity_y,
                                                  float gravity_z)
{
    return hybrid_compute(accel_x,
                          accel_y,
                          accel_z,
                          gravity_x,
                          gravity_y,
                          gravity_z,
                          false);
}

/* -------------------------------------------------------------------------- */

hybrid_pitch_roll_data_t Hybrid_pitch_roll_update_double(float accel_x,
                                                         float accel_y,
                                                         float accel_z,
                                                         float gravity_x,
                                                         float gravity_y,
                                                         float gravity_z)
{
    return hybrid_compute(accel_x,
                          accel_y,
                          accel_z,
                          gravity_x,
                          gravity_y,
                          gravity_z,
                          true);
}
