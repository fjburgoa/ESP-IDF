
#include <math.h>

#include "esp_log.h"
#include "nvs_flash.h"
#include "wifi_ap.h"
#include "webserver.h"
#include "websocket.h"
#include "esp_wifi.h"

#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "EFIS_I2C.h"
#include "freertos/semphr.h"

#include "BMP280.h"
#include "BNO086.h"
#include "GPS.h"

#include "driver/gpio.h"

#include "config.h"

#if DATALOGGER_ENABLED
#include "DataLogger.h"
#endif

static const char *TAG = "MAIN";

/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
/*************************************************************************/

#define LED4 4
#define LOW 0
#define HIGH 1

void app_main(void)
{

    // configura GPIO4 como salida digital
    gpio_set_direction(LED4, GPIO_MODE_OUTPUT);
    gpio_set_level(LED4, LOW);
    vTaskDelay(pdMS_TO_TICKS(250));

    esp_err_t err = nvs_flash_init();
    if ((err == ESP_ERR_NVS_NO_FREE_PAGES) || (err == ESP_ERR_NVS_NEW_VERSION_FOUND))
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    else
    {
        ESP_ERROR_CHECK(err);
    }
    vTaskDelay(pdMS_TO_TICKS(STARTUP_BNO_TO_BMP_DELAY_MS));
    ESP_ERROR_CHECK(efis_i2c_init());

    gpio_set_level(LED4, HIGH);
    vTaskDelay(pdMS_TO_TICKS(1000));

    vTaskDelay(pdMS_TO_TICKS(STARTUP_I2C_TO_BNO_DELAY_MS));
    ESP_ERROR_CHECK(BNO086_start());

    vTaskDelay(pdMS_TO_TICKS(0.5 * STARTUP_BNO_TO_BMP_DELAY_MS));
    ESP_ERROR_CHECK(bmp280_start());

    vTaskDelay(pdMS_TO_TICKS(STARTUP_GPS_TO_I2C_DELAY_MS));
    ESP_ERROR_CHECK(GPS_start());

    /* DataLogger SPIFFS: activacion centralizada en config.h. */
#if DATALOGGER_ENABLED
    esp_err_t logger_err = DataLogger_start();

    if (logger_err != ESP_OK)
    {
        ESP_LOGE(TAG, "DataLogger no disponible: %s", esp_err_to_name(logger_err));
    }
#endif

    ESP_ERROR_CHECK(wifi_ap_start()); // arranca el Access point

    httpd_handle_t server = webserver_start(); // arranca el servidor web http
    if (server == NULL)
    {
        ESP_LOGE(TAG, "No se ha podido iniciar el servidor web");
        return;
    }

    ESP_ERROR_CHECK(websocket_start_dummy_stream(server)); // Register WebSocket endpoint

    ESP_ERROR_CHECK(esp_wifi_set_max_tx_power(WIFI_TX_POWER_QDBM));

    int8_t power = 0;

    ESP_ERROR_CHECK(esp_wifi_get_max_tx_power(&power));

    ESP_LOGI(TAG, "WiFi TX power = %.1f dBm", power / 4.0f);

    ESP_LOGI(TAG, "Sistema iniciado correctamente");
}
