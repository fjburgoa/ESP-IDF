#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "BNO055.h"
#include "EFIS_I2C.h"
#include "MPU6050.h"
#include "settings.h"
#include "usb_hid.h"

static const char *TAG = "EFIS_USB";

void app_main(void)
{
    ESP_ERROR_CHECK(settings_init());

    ESP_ERROR_CHECK(efis_i2c_init());

    ESP_ERROR_CHECK(MPU6050_start());

    vTaskDelay(pdMS_TO_TICKS(200));

    ESP_ERROR_CHECK(BNO055_start());

    ESP_ERROR_CHECK(usb_hid_start());

    ESP_LOGI(TAG, "EFIS USB iniciado");
}
